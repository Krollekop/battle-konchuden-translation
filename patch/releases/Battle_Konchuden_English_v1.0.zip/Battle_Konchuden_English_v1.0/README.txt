BATTLE KONCHŪDEN — ENGLISH TRANSLATION
Version 1.0

Thank you for downloading the English translation patch for Battle Konchūden, a Japanese PlayStation game released in 1999.

INSTALLATION

1. Make sure you have a legally obtained copy of the original Japanese PlayStation game in BIN/CUE format.
2. Use a PPF-compatible patching utility to apply the included .ppf file to the appropriate original BIN file.
3. Make sure the CUE file references the patched BIN file.
4. Use chdman to convert the patched BIN/CUE image to CHD, if desired.
5. Load the resulting image in a compatible PlayStation emulator.

Please back up your original game image before applying the patch.

ABOUT THIS PATCH

This is an unofficial fan translation. It is not affiliated with or endorsed by Jaleco or any other rights holder.

The patch does not include the original game.

FEEDBACK

If you encounter a bug or translation issue, please report it through the project's GitHub Issues page.

Thank you for your interest in this project!